function myFunction() {
    document.getElementById("demo").innerHTML = "Paragraph changed.";
 }